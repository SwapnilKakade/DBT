/*
Write a procedure to display the department number and employee name in the following format.
10 -> (AARAV, THOMAS, CLARK, KING, MILLER)
20 -> (SHARMIN, BANDISH, SMITH, JONES, SCOTT, FRED, ADAMS, FORD)
30 -> (GITA, ALLEN, WARD, MARTIN, BLAKE, TURNER, JAMES, HOFFMAN, GRASS)
40 –> (No employee work in department 40…)
50 -> (VRUSHALI, SANGITA, SUPRIYA)
*/

DROP PROCEDURE IF EXISTS deptEmp;
DELIMITER %
CREATE PROCEDURE deptEmp()
BEGIN
	
END %
DELIMITER ;